#REDIRECT inkCartridge.md
